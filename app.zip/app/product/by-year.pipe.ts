import {Pipe, PipeTransform} from "@angular/core";

//{{products | byYear:2010}}
@Pipe({
    name: 'byYear'
})
export class ByYearPipe implements PipeTransform {
    transform(products: any, year: number) {
        if (!year) {
            return products;
        }

        var results:any = [];

        for(let i in products) {
            if (products[i].year == year) {
                results.push(products[i]);
            }
        }

        return results;
    }
}