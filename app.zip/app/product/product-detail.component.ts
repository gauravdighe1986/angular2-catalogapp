import {Component} from "@angular/core";
import {Http, Response} from "@angular/http";
import {ActivatedRoute, Params} from "@angular/router";

import {Router} from "@angular/router";

import {Inject} from "@angular/core";

import {ConfirmDirective} from "../shared/confirm.directive";

import {ProductInfoComponent} from "../shared/product-info.component";

@Component({
    templateUrl: 'app/product/product-detail.component.html',
    directives: [ConfirmDirective, ProductInfoComponent]
})
export class ProductDetailComponent {
    productId : number;
    product:any = {};

    constructor(private route: ActivatedRoute, 
                private http:Http,
                @Inject("apiEndPoint") private apiEndPoint: string,
                private router: Router
                ) {

        this.route.params.forEach((params: Params) => {
            this.productId = params['id'];
            console.log("Product id is ", this.productId);
        });

        this.http.get(this.apiEndPoint + "/api/products/" + this.productId)
        .map((response: Response) => response.json())
        .subscribe((data : any) => {
            this.product = data;
        })

    }

    editProduct() {
        console.log("Edit Product Event");
        this.router.navigate(['/products/edit/' + this.product.id]);
    }

    deleteProduct() {
        console.log("Delete product now");
    }


}
