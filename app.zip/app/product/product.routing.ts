import {RouterModule, Routes} from "@angular/router";

import {ProductComponent} from "./product.component";
import {ProductListComponent} from "./product-list.component";

import {ProductDetailComponent} from "./product-detail.component";
import {ProductEditComponent} from "./product-edit.component";

import {AuthGuard} from "../auth/auth.guards";

const routes: Routes = [
    {
        path: 'products',
        component: ProductComponent,

        children:[
            {
                path:'',
                component: ProductListComponent,
                canActivate: [AuthGuard]
            },

            {
                path: 'detail/:id',
                component: ProductDetailComponent,
                 canActivate: [AuthGuard]
            },

            {
                path: 'edit/:id',
                component: ProductEditComponent,
                canActivate: [AuthGuard]
            },

            {
                path: 'create',
                component : ProductEditComponent,
                canActivate: [AuthGuard]
            }
        ]
    }
]

export const productRouting = RouterModule.forRoot(routes);