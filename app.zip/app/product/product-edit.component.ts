import {Component} from "@angular/core";
import {Http, Response} from "@angular/http";

import {Headers, RequestOptions} from "@angular/http";

import {Router, ActivatedRoute, Params} from "@angular/router";

import {Inject} from "@angular/core";

@Component({
    templateUrl: 'app/product/product-edit.component.html'
})
export class ProductEditComponent {
    productId : number;
    product:any = {};

    message: string;

    constructor(private route: ActivatedRoute, 
                private http:Http,
                @Inject("apiEndPoint") private apiEndPoint: string,
                private router:Router
                ) {

        this.route.params.forEach((params: Params) => {
            this.productId = params['id'];
            console.log("Product id is ", this.productId);
        });

        if (this.productId) {
            this.http.get(this.apiEndPoint + "/api/products/" + this.productId)
            .map((response: Response) => response.json())
            .subscribe((data : any) => {
                this.product = data;
            })
        }

    }

    saveProduct() {
        console.log(this.product.name);

        console.log(JSON.stringify(this.product));

        let body = JSON.stringify(this.product);

        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });

        if (this.product.id) {
            this.http.put(this.apiEndPoint + '/api/products/' + this.product.id, 
            body, 
            options)
            .map((response: Response) => response.json())
            .subscribe((data: any) => {
                this.product = data;
                this.message = "Product information saved";
                setTimeout(() => {
                    this.router.navigate(['/products']);
                }, 1000);
            });
        } else { //create new product 
        
            this.http.post(this.apiEndPoint + '/api/products', 
            body, 
            options)
            .map((response: Response) => response.json())
            .subscribe((data: any) => {
                this.product = data;
                this.message = "Product information saved";
                
                /*setTimeout(() => {
                    this.router.navigate(['/products']);
                }, 1000);*/

            });


        }

    }
 
}
