import {Component} from "@angular/core";

@Component({
    templateUrl:'app/product/product.component.html'
})
export class ProductComponent {
    
}