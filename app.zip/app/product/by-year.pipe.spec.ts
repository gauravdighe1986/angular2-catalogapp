describe('Pipe: CapitalisePipe', () => {
   
 
  it('should work with empty string', () => {
    expect(true).toEqual(true);
  });
   
}) 