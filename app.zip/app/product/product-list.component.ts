import {Component, Inject} from "@angular/core";
import {OnInit} from "@angular/core";

import {ProductInfoComponent} from "../shared/product-info.component";

import {Http, Response, Headers, RequestOptions} from "@angular/http";
import {AuthService} from "../auth/auth.service";

@Component({
    templateUrl: 'app/product/product-list.component.html',
    directives: [ProductInfoComponent]
})
export class ProductListComponent implements OnInit {

    products: any;
    
    constructor(private http:Http,
              @Inject("apiEndPoint") private apiEndPoint: string,
              private authService: AuthService
    ) {
       
    }

    ngOnInit() {
        console.log("ProductListComponent OnInit");
        this.refresh();
    }

    refresh() {
        //GET /api/products
        console.log("Sending requsts");
        let headers: Headers = new Headers ({
            "Authorization" : "Bearer " + this.authService.getToken()
        });

        let options = new RequestOptions({headers: headers});

        this.http.get(this.apiEndPoint + '/api/products', options)
        .map((response : Response) => response.json())
        .subscribe((data: any) => this.products = data );
    }

    deleteProduct(id: any) {
        console.log('delete ', id);
        this.http.delete(this.apiEndPoint + '/api/products/' + id)
        .subscribe(() => this.refresh() )

        /*
        .subscribe((response : Response) => {
            console.log("Deleted");

            this.products.forEach((p:any, i:number) => {
                if (p.id == id) { this.products.splice(i, 1); }
            });
            
        })*/
    }

    ngOnDestroy() {
        console.log("ProductListComponent ngOnDestroy");
    }


}