import {Directive, Input,  HostListener} from "@angular/core";

@Directive({
    selector: '[confirm]'
})
export class ConfirmDirective {
    @Input("confirm") 
    onConfirmed: Function = () => {};

    constructor() {
    }

    @HostListener("mouseover", ["$event"])
    mouseOver($event: any) {
       console.log("mosueover");
    }

    @HostListener("click", ["$event"])
    confirmFirst($event: any) {
        let confirmed = window.confirm("Do you want to proceed");
        if (confirmed) {
            this.onConfirmed();
        }
    }
}