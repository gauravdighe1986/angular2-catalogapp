import {Component, Input} from "@angular/core";
 
@Component({
    selector : '[productInfo]',
    template: `
        <span>RAM {{product.ram}}</span> <br />
        <span>Weight {{product.weight}}</span> <br />
    `
})
export class ProductInfoComponent {
    @Input("productInfo")
    product: any;

    constructor()
    {

    }
}