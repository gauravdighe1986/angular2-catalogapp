import {Injectable} from "@angular/core";

@Injectable()
export class ContactService {
    contacts: any;

    constructor()
    {
         this.contacts = [
            {
                id: 1,
                name: 'Example, Inc',
                address:{
                    street: 'Park Drive'
                }
            }
        ];
    }

    getContacts() {
        return this.contacts;
    }
}