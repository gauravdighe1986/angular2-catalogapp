import {RouterModule, Routes} from "@angular/router";

import {ContactComponent} from "./contact.component";

const routes: Routes = [
    {
        path: 'home',
        component: ContactComponent
    } 
]

export const contactRouting = RouterModule.forRoot(routes);