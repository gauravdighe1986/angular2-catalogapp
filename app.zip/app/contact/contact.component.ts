import {Component} from "@angular/core";
import {ContactService} from "./contact.service";

@Component({
    selector: 'contact',
    templateUrl : 'app/contact/contact.component.html',
    providers: [ContactService]
})
export class ContactComponent {
    contacts: any;

    constructor(contactService:ContactService) {
      this.contacts = contactService.getContacts();
    }
}