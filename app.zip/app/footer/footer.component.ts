import {Component} from "@angular/core";

@Component({
    selector: 'footer',
    template: `
    <p>
        Footer - Example, Inc
    </p>
    `
})
export class FooterComponent {
    
}