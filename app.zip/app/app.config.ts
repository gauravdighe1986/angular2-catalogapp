
export const apiEndPoint:string = "http://localhost:7070";
