import {Component} from "@angular/core";

import {Routes, RouterModule} from "@angular/router";

import {ExceptionHandler} from "@angular/core";

//application level exception handler
export class ApplicationExceptionHandler extends ExceptionHandler {
     call(exception: any, stackTrace?: any, reason?: string): void{
         console.log("Application error ");
         console.log("Error ", exception);
         console.log("stackTrace", stackTrace);

         window.location.assign("http://localhost:3000/error");
     }
}

@Component({
    template:`
       <h3> The page/url you are looking for does not exist </h3>
    `
})
export class PageNotFoundErrorComponent {

}


@Component({
    template:`
       <h3> Error in application </h3>
    `
})
export class ErrorComponent {

}

@Component({
    template: 'error '
})
export class ThrowErrorComponent{
    constructor() {
        throw new Error("NAN Exception");
    }
}

const routes:Routes = [
    {
        path: "throwerror",
        component: ThrowErrorComponent
    },

     {
        path: "error",
        component: ErrorComponent

    },

    {
        path: "**",
        redirectTo: 'pagenotfound'
    },

    {
        path: 'pagenotfound',
        component: PageNotFoundErrorComponent
    }

   

]

export const errorRouting = RouterModule.forRoot(routes);


