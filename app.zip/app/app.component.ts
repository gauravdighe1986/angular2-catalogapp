import { Component } from '@angular/core'; 

import {AuthService} from "./auth/auth.service";
import {Subject}    from 'rxjs/Subject';
import {Router} from "@angular/router";

@Component({
    selector: 'my-app',
   templateUrl: 'app/app.component.html'
})
export class AppComponent {
    authenticated: boolean = false;

    constructor(private authService: AuthService,
                private router: Router) {

        this.setAuthState(this.authService.isAuthenticated());

        this.authService.getAuthNotification()
        .subscribe((result: boolean) => this.setAuthState(result));
    }

    setAuthState(value: boolean){
        this.authenticated = value;
        console.log("login changed ", value);
    }

    logout() {
        this.authService.logout();
        this.router.navigate(["/auth/login"]);
    }
 }

@Component({
    selector: 'my-app2',
    templateUrl: 'app/app.component.html'
    //template: '<h1>Hello Angular 2</h1>'
})
 export class App2Component {

 }
