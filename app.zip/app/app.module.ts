import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import {RouterModule} from "@angular/router";

import {FormsModule} from "@angular/forms";

import {HttpModule} from "@angular/http";
 
import { AppComponent }  from './app.component';
 
import {HomeComponent} from "./home/home.component";
import {AboutComponent} from "./about/about.component"
import {ContactComponent} from "./contact/contact.component"; 
import {FooterComponent} from "./footer/footer.component";

import {AuthService} from "./auth/auth.service";

import {homeRouting} from "./home/home.routing";
import {aboutRouting} from "./about/about.routing";
import {productRouting} from "./product/product.routing";
import {errorRouting} from "./error/error.component";
import {authRouting} from "./auth/auth.routing";

import {ByYearPipe} from "./product/by-year.pipe";
import {apiEndPoint} from "./app.config";


import {ExceptionHandler} from "@angular/core";
import {ApplicationExceptionHandler} from "./error/error.component";

import {AuthGuard} from "./auth/auth.guards";

import {LocationStrategy, HashLocationStrategy} from "@angular/common";


@NgModule({
  imports: [ 
      BrowserModule, 
      HttpModule,
      FormsModule,
      RouterModule,

      homeRouting,
      aboutRouting,
      productRouting,
      authRouting
      ,errorRouting
      ],
  declarations: [ 
      AppComponent, 
      AboutComponent,
      ContactComponent,
      FooterComponent,
      HomeComponent,
      ByYearPipe
    ],

  providers: [
   {
       "provide": "apiEndPoint",
        useValue: apiEndPoint
   },

   {
       "provide": AuthService,
       useClass: AuthService
   },


    {
        "provide": LocationStrategy,
        useClass: HashLocationStrategy
    },

   AuthGuard
   
    
   //Enable this to handle exceptions
  /*{
       "provide": ExceptionHandler,
       useClass : ApplicationExceptionHandler
   }*/
  ],

  bootstrap: [ 
      AppComponent,
      FooterComponent
     ]
})
export class AppModule { }

console.log("module load");