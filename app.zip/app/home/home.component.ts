import {Component} from "@angular/core";

import {Http, Response} from "@angular/http";
import {OnInit, Inject} from "@angular/core";

import 'rxjs/add/operator/toPromise';

@Component({
    selector: 'home',
      styles : [
        `
        #wrapper {
        margin-right: 50%;
        }
        #products {
        float: left;
        width: 100%;
        background-color: #CCF;
        }
        #brands {
        float: right;
        width: 50%;
        margin-right: -50%;
        background-color: #DCF;
        }
        #cleared {
        clear: both;
        }
        `
    ],

    templateUrl: "app/home/home.component.html"
    
})
export class HomeComponent implements OnInit{
    products: any;
    brands:any;

    constructor(private http:Http,
     @Inject("apiEndPoint") private apiEndPoint: string
    ) {

    }
 
      
    ngOnInit() {
       Promise.all([
              this.http.get(this.apiEndPoint + '/api/products')
                .toPromise(),

              this.http.get(this.apiEndPoint + '/api/brands')
              .toPromise()
        ])
        .then((results : any) => {
            let response1: any = results[0];
            let response2:any = results[1];

            this.products  = response1.json();
            this.brands = response2.json();
        })
    }

    /*

    
    ngOnInit2() {
 
         this.http.get(this.apiEndPoint + '/api/products')
         .map((response : Response) => response.json())
         .subscribe((data: any) => this.products = data );

        this.http.get(this.apiEndPoint + '/api/brands')
        .map((response : Response) => response.json())
        .subscribe((data: any) => this.brands = data );
    }

    
    ngOnInit3() {
 
         this.http.get(this.apiEndPoint + '/api/products')
         .toPromise()
         .then((response: Response) => {
             this.products = response.json();
         })

        this.http.get(this.apiEndPoint + '/api/brands')
        .toPromise()
         .then((response: Response) => {
             this.brands = response.json();
         })
         
    }
    */
}