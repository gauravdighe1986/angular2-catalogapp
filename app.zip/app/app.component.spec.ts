/* tslint:disable:no-unused-variable */
import { AppComponent, App2Component } from './app.component';

import { TestBed, async,  inject, ComponentFixture } from '@angular/core/testing';

import { By }             from '@angular/platform-browser';

////////  SPECS  /////////////

/// Delete this
describe('Smoke test', () => {
  it('should run a passing test', () => {
    expect(true).toEqual(true, 'should pass');
  });
});

describe('AppComponent with TCB', function () {
 
  beforeEach(() => {
    TestBed.configureTestingModule({declarations: [App2Component]});
  });
 
 beforeEach(() => {
      TestBed.compileComponents();
  });


  it('should instantiate component', () => {
    let fixture = TestBed.createComponent(App2Component);
    expect(fixture.componentInstance instanceof App2Component).toBe(true, 'should create App2Component');
  });

  it('should have expected <h1> text', () => {
    let fixture = TestBed.createComponent(App2Component);
    fixture.detectChanges();

    let h1 = fixture.debugElement.query(el => el.name === 'h1').nativeElement;  // it works
    // h1 = fixture.debugElement.query(By.css('h1')).nativeElement;            // preferred

    expect(h1.innerText).toMatch(/Hello Angular 2/i, 'Hello Angular 2');
  });


});
