import {Component} from "@angular/core";

import {AuthService} from "./auth.service";

import {Router} from "@angular/router";

@Component({
    templateUrl: "app/auth/login.component.html"
})
export class LoginComponent {
    username: string = '';
    password: string = '';

    errorMessage : string = '';

    constructor(private authService:AuthService,
                private router: Router
    ) {
    }

    login() {
        console.log("login component ", this.username, this.password);

        this.authService.authenticate(this.username, this.password)
        .subscribe(data => {
            console.log("Data ", data);

            let pathToGo:string = this.authService.getRedirectUrl();

            if (pathToGo) {
                this.authService.clearRedirectUrl();
                this.router.navigate([pathToGo]);
            }
        },
        
        error => {
            console.log(error);
            this.errorMessage = "Invalid username/password";
        })
     }
}