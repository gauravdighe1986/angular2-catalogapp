import {Routes, RouterModule} from "@angular/router";

import {AuthGuard} from "./auth.guards";
import {LoginComponent} from "./login.component";

var routes:Routes = [{
  path : 'auth/login',
  component:   LoginComponent
}]

export const authRouting = RouterModule.forRoot(routes);